//
//  DesignApp.swift
//  Design
//
//  Created by Aluno Mack on 18/03/25.
//

import SwiftUI

@main
struct DesignApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
